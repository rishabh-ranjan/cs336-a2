# CS336 Spring 2024 Assignment 2: Systems

Please write your code for assignment 2 in this directory.

To run unit tests (assuming you've followed the setup instructions in [the
parent directory's README.md](../README.md)):

``` sh
pytest -v
```
